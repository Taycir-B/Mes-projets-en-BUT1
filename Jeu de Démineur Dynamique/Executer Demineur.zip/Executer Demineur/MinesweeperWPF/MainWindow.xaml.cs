﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace MinesweeperWPF
{
    public partial class MainWindow : Window
    {
        private int gridSize = 10;      // taille du grid
        private int nbMines = 10;       // nombre de bombes
        private int nbCellsChecked = 0; // nombre de case qui ont étè ouvertes
        private int[,] matrix;          // matrix preserving grid values (see below)
        private int nbCellNoBomb;       // nombre de cases sans bombes

        public MainWindow()
        {
            InitializeComponent();
            Initialize();
        }

        // initialisation d'une partie de démineur
        private void Initialize()
        {
            matrix = new int[gridSize, gridSize];
            nbCellsChecked = 0;
            GRDGame.Children.Clear();
            GRDGame.ColumnDefinitions.Clear();
            GRDGame.RowDefinitions.Clear();
            initializeMatrix();
            nbCellNoBomb = gridSize * gridSize - nbMines;

            for (int i = 0; i < gridSize; i++)
            {
                GRDGame.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
                GRDGame.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
                for (int j = 0; j < gridSize; j++)
                {
                    Border b = new Border
                    {
                        BorderThickness = new Thickness(1),
                        BorderBrush = new SolidColorBrush(Colors.DarkSlateBlue)
                    };
                    b.SetValue(Grid.RowProperty, j);
                    b.SetValue(Grid.ColumnProperty, i);
                    GRDGame.Children.Add(b);

                    Grid innGrid = new Grid
                    {
                        Background = new SolidColorBrush(Colors.LightSteelBlue)
                    };
                    b.Child = innGrid;

                    Label l = new Label();
                    l.Content = matrix[i, j].ToString();
                    innGrid.Children.Add(l);

                    Button bu = new Button
                    {
                        Background = new SolidColorBrush(Colors.CadetBlue),
                        Foreground = new SolidColorBrush(Colors.White)
                    };
                    bu.Click += Button_Click;
                    innGrid.Children.Add(bu);
                    if (matrix[i, j] == -1)
                        l.Content = "B";
                    else if (matrix[i, j] == 0)
                        l.Content = null;
                }
            }
        }

        // initialisation de la matrice (grillage)
        private void initializeMatrix()
        {
            bool repeat = false;
            for (int i = 0; i < nbMines; i++)
            {
                do
                {
                    Random rand = new Random();
                    int randomRow = rand.Next(gridSize);
                    int randomCol = rand.Next(gridSize);
                    if (matrix[randomRow, randomCol] == -1)
                    {
                        repeat = true;
                    }
                    else
                    {
                        matrix[randomRow, randomCol] = -1;
                        repeat = false;
                        for (int j = Math.Max(0, randomRow - 1); j <= Math.Min(gridSize - 1, randomRow + 1); j++)
                        {
                            for (int k = Math.Max(0, randomCol - 1); k <= Math.Min(gridSize - 1, randomCol + 1); k++)
                            {
                                if (matrix[j, k] != -1)
                                {
                                    matrix[j, k] += 1;
                                }
                            }
                        }
                    }
                }
                while (repeat);
            }
        }

        // pour quand on clique sur le bouton JOUER
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            Border b = (Border)VisualTreeHelper.GetParent(VisualTreeHelper.GetParent(button));
            int col = Grid.GetColumn(b);
            int row = Grid.GetRow(b);
            checkCell(col, row);
        }

        // vérifier le contenu de la case
        private bool checkCell(int col, int row)
        {
            Border b = (Border)GetUIElementFromPosition(GRDGame, col, row);
            Grid g = (Grid)b.Child;
            Button button = (Button)g.Children[1];
            if (button.Visibility == Visibility.Visible)
            {
                button.Visibility = Visibility.Hidden;
                if (matrix[col, row] == -1)
                {
                    MessageBox.Show("Perdu! ", "Perdant", MessageBoxButton.OK);
                    Initialize();
                    return true;
                }
                else
                {
                    nbCellsChecked += 1;
                    if (nbCellsChecked == nbCellNoBomb)
                    {
                        MessageBox.Show("Bravo, vous avez gagné ! ", "Gagnant", MessageBoxButton.OK);
                        Initialize();
                        return true;
                    }
                    else
                    {
                        if (matrix[col, row] == 0)
                        {
                            for (int i = Math.Max(0, col - 1); i <= Math.Min(gridSize - 1, col + 1); i++)
                            {
                                for (int j = Math.Max(0, row - 1); j <= Math.Min(gridSize - 1, row + 1); j++)
                                {
                                    bool result = checkCell(i, j);
                                    if (result)
                                    {
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }

        private UIElement GetUIElementFromPosition(Grid g, int col, int row)
        {
            return g.Children.Cast<UIElement>().First(e => Grid.GetRow(e) == row && Grid.GetColumn(e) == col);
        }

        // Permettre de changer la grille et les bombes avec les valeurs choisies par l'utilisateur
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int.TryParse(tailleGrille.Text, out gridSize);
            int.TryParse(nbBombes.Text, out nbMines);
            if (gridSize <= 0)
            {
                gridSize = 10; // taille par défaut
            }
            if (nbMines <= 0)
            {
                nbMines = 10; // nombre de bombes par défaut
            }
            Initialize();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}

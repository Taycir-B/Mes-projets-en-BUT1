package modeles;

public class Session {

	Epreuve sonEpreuve;
	Resultat sonResultat;
	private int numero;
	private String dateDebut;
	private String duree;
	private String description;
	private String sport;

	private static int nbSession = 0;

	/**
	 * 
	 * @param sport
	 * @param dateDebut
	 * @param duree
	 * @param description
	 */
	public Session(String sport, String dateDebut, String duree, String description) {
		this.sport = sport;
		this.dateDebut = dateDebut;
		this.duree = duree;
		this.description = description;
	}

	public String[] getAffichage() {
		return new String[] {sport, dateDebut, duree, description};
	}

	/**
	 * 
	 * @param nouvelleDate
	 */
	public void modifierDateDebut(String nouvelleDate) {
		// TODO - implement modeles.Session.modifierDateDebut
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nouvelleDate
	 */
	public void modifierDateFin(String nouvelleDate) {
		// TODO - implement modeles.Session.modifierDateFin
		throw new UnsupportedOperationException();
	}

	public boolean resultatExiste() {
		// TODO - implement modeles.Session.resultatExiste
		throw new UnsupportedOperationException();
	}

}
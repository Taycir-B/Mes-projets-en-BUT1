package modeles;

public class Resultat {

	Session saSession;
	private int numero;
	private String score;

	/**
	 * 
	 * @param numero
	 * @param score
	 */
	public Resultat(int numero, String score) {
		// TODO - implement modeles.Resultat.modeles.Resultat
		throw new UnsupportedOperationException();
	}

}
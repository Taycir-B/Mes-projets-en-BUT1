package modeles;

public class Utilisateur {

	private int id;
	private String nom;
	private String prenom;
	private int age;
	private String mail;

	/**
	 *
	 * @param nom
	 * @param prenom
	 * @param age
	 * @param mail
	 */
	public Utilisateur(String nom, String prenom, int age, String mail) {
		this.nom = nom;
		this.prenom = prenom;
		this.age = age;
		this.mail = mail;
	}

	protected boolean estUnAthlete() {
		// TODO - implement modeles.Utilisateur.estUnAthlete
		throw new UnsupportedOperationException();
	}

}
package modeles;
import java.util.*;

public class Athlete extends Utilisateur {

	Equipe sonEquipe;
	Pays sonPays;
	ArrayList<Medaille> sesMedailles;
	private String taille;
	private String poids;

	/**
	 *
	 *
	 * @param nom
	 * @param prenom
	 * @param age
	 * @param mail
	 * @param poids
	 * @param taille
	 */
	public Athlete(String nom, String prenom, int age, String mail, String poids, String taille) {

		super(nom, prenom, age, mail);
		this.taille = taille;
		this.poids = poids;

	}

}
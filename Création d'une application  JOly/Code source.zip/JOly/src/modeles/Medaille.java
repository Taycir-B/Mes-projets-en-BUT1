package modeles;

public class Medaille {

	Epreuve sonEpreuve;
	Pays sonPays;
	Equipe sonEquipe;
	Athlete sonAthlete;
	private String numero;
	private int niveauMedaillle;

	/**
	 * 
	 * @param numero
	 * @param niveau
	 */
	public Medaille(int numero, String niveau) {
		// TODO - implement modeles.Medaille.modeles.Medaille
		throw new UnsupportedOperationException();
	}

}
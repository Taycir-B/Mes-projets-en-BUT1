package modeles;

import java.util.*;

public class Epreuve {

	ArrayList<Session> sesSessions;
	ArrayList<Equipe> sesEquipes;
	Medaille sonMedaille;
	private int numero;
	private String nom;
	private String lieu;
	private String type;
	private int duree;

	/**
	 * 
	 * @param numero
	 * @param nom
	 * @param lieu
	 * @param type
	 * @param duree
	 */
	public Epreuve(int numero, String nom, String lieu, String type, int duree) {
		// TODO - implement modeles.Epreuve.modeles.Epreuve
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param resultat
	 */
	public void ajoutResultat(Resultat resultat) {
		// TODO - implement modeles.Epreuve.ajoutResultat
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param lieu
	 */
	public void modifierLieu(String lieu) {
		// TODO - implement modeles.Epreuve.modifierLieu
		throw new UnsupportedOperationException();
	}

	public ArrayList<Epreuve> afficherPlanningAVenir() {
		// TODO - implement modeles.Epreuve.afficherPlanningAVenir
		throw new UnsupportedOperationException();
	}

	public boolean epreuveExiste() {
		// TODO - implement modeles.Epreuve.epreuveExiste
		throw new UnsupportedOperationException();
	}

	public boolean debutEstValide() {
		// TODO - implement modeles.Epreuve.debutEstValide
		throw new UnsupportedOperationException();
	}

	public boolean finEstValide() {
		// TODO - implement modeles.Epreuve.finEstValide
		throw new UnsupportedOperationException();
	}

}
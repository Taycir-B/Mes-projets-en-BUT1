package modeles;

import java.util.*;

public class Pays {

	static int nbPays = 0;
	ArrayList<Athlete> sesAthletes;
	ArrayList<Equipe> sesEquipes;
	ArrayList<Medaille> sesMedailles;
	private int code;
	private String nom;

    /**
	 * 
	 * @param medaille
	 */
	public void ajoutMedaille(Medaille medaille) {
		// TODO - implement modeles.Pays.ajoutMedaille
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param equipe
	 */
	public void ajoutEquipe(Equipe equipe) {
		// TODO - implement modeles.Pays.ajoutEquipe
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param code
	 * @param nom
	 */
	public Pays(String nom) {
		this.code = nbPays;
		this.nom = nom;
		this.sesAthletes = new ArrayList<Athlete>();
		this.sesEquipes = new ArrayList<Equipe>();
		this.sesMedailles = new ArrayList<Medaille>();
		nbPays++;
	}

	/**
	 * 
	 * @param athlete
	 */
	public void ajoutAthlete(Athlete athlete) {
		// TODO - implement modeles.Pays.ajoutAthlete
		throw new UnsupportedOperationException();
	}

	public void afficheMedailles() {
		// TODO - implement modeles.Pays.afficheMedailles
		throw new UnsupportedOperationException();
	}

	public String getNom() {
		return this.nom;
	}
}
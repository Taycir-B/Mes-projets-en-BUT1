package vues.session;

import controleurs.session.SessionPlanningRetourListener;
import modeles.Session;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class SessionPlanningPanel extends JPanel {

    private JTable table;

    private DefaultTableModel tableModel;

    private JScrollPane scrollPane;

    private String[] columns = {"Epreuve", "Debut", "Duree", "Type"};

    private String[][] data = new String[][]{};

    ArrayList<Session> sessions = new ArrayList<>();

    public SessionPlanningPanel() {

        setSize(1000, 700);

        table = new JTable();

        scrollPane = new JScrollPane(table);

        // Setting the layout
        setLayout(new BorderLayout());

        // Creating the top panel for the title and the Olympic rings
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(new Color(255, 215, 0)); // Color jaune

        // Adding title
        JLabel title = new JLabel("Planning des sessions", JLabel.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        topPanel.setPreferredSize(new Dimension(1000, 100));

        // Adding a back button on the top left corner
        ImageIcon returnIcon = new ImageIcon("images/fleche_retour.png"); // Path to your back arrow image
        Image returnImage = returnIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH); // Resize image to 30x30
        returnIcon = new ImageIcon(returnImage);
        JLabel backLabel = new JLabel(returnIcon);
        JButton backButton = new JButton(returnIcon);

        backButton.setPreferredSize(new Dimension(50, 50));
        backButton.setBackground(Color.YELLOW);
        backButton.addActionListener(new SessionPlanningRetourListener());
        //topPanel.add(Box.createRigidArea(new Dimension(25, 0)));
        topPanel.add(backButton);
        topPanel.add(Box.createRigidArea(new Dimension(300, 0)));
        topPanel.add(title);

        add(topPanel, BorderLayout.NORTH);

        // Creating the center panel for the table
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridBagLayout()); // Using GridBagLayout for centering
        centerPanel.setBackground(new Color(255, 215, 0)); // Color jaune


        refreshPanel();


        table.setBackground(new Color(255, 215, 0)); // Color jaune
        JScrollPane scrollPane = new JScrollPane(table);

        // Centering the table
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        centerPanel.add(scrollPane, gbc);

        add(centerPanel, BorderLayout.CENTER);

    }

    public void addSession(Session session) {
        sessions.add(session);
        refreshPanel();
    }

    private void refreshPanel() {

        data = new String[sessions.size()][4];
        for (int i = 0; i < sessions.size(); i++) {
            data[i] = sessions.get(i).getAffichage();
        }

        tableModel = new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Makes the table cells non-editable
            }
        };

        table.setModel(tableModel); // Set the view of the existing JScrollPane to the new JTable

        revalidate();
        repaint();
    }

    // Method to resize an image
    private Image resizeImage(ImageIcon originalImage, int targetWidth, int targetHeight) {
        Image resultingImage = originalImage.getImage().getScaledInstance(targetWidth, targetHeight, Image.SCALE_DEFAULT);
        return resultingImage;
    }
}

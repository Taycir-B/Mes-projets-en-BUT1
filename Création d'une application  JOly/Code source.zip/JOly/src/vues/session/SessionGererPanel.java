package vues.session;

import controleurs.session.SessionAjouterListener;
import controleurs.session.SessionGererRetourListener;

import javax.swing.*;
import java.awt.*;

public class SessionGererPanel extends JPanel {

    private JTextField sportField;
    private JTextField startDateField;
    private JTextField durationField;
    private JTextField descriptionField;

    public SessionGererPanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        setBackground(new Color(255, 215, 0)); // Golden background color

        ImageIcon returnIcon = new ImageIcon("images/fleche_retour.png");
        Image returnImage = returnIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        returnIcon = new ImageIcon(returnImage);
        JButton backButton = new JButton(returnIcon);
        backButton.setPreferredSize(new Dimension(50, 50));

        backButton.addActionListener(new SessionGererRetourListener());
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        add(backButton, gbc);

        // Title
        JLabel titleLabel = new JLabel("Gerer les Sessions", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.NORTH;
        add(titleLabel, gbc);

        // Sport
        JLabel sportLabel = new JLabel("Sport:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        add(sportLabel, gbc);

        sportField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(sportField, gbc);

        // Start Date
        JLabel startDateLabel = new JLabel("Date de debut:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(startDateLabel, gbc);

        startDateField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(startDateField, gbc);

        // Duration
        JLabel durationLabel = new JLabel("Duree (HH:MM):");
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(durationLabel, gbc);

        durationField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 3;
        add(durationField, gbc);

        // Description
        JLabel descriptionLabel = new JLabel("Description:");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        add(descriptionLabel, gbc);

        descriptionField = new JTextField(20);
        JScrollPane scrollPane = new JScrollPane(descriptionField);
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.fill = GridBagConstraints.BOTH;
        add(scrollPane, gbc);

        // Add Session Button
        JButton addSessionButton = new JButton("Ajouter Session");
        addSessionButton.setBackground(new Color(0, 128, 0)); // Green color
        addSessionButton.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        add(addSessionButton, gbc);
        addSessionButton.addActionListener(new SessionAjouterListener(sportField, startDateField, durationField, descriptionField));

    }
}

package vues.session;
import controleurs.session.SessionAfficherListener;
import controleurs.session.SessionLoginListener;
import controleurs.session.SessionRetourListener;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class SessionChoicePanel extends JPanel {

    private BufferedImage logoImage;
    private JLabel logoLabel;

    public SessionChoicePanel() {

        setSize(1000, 700);

        setLayout(new BorderLayout());

        setBackground(new Color(255, 215, 0));

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        // Load logo image
        try {
            logoImage = ImageIO.read(new File("images/equipe_back_icon.png"));
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Add logo image
        logoLabel = new JLabel(new ImageIcon(logoImage));
        add(logoLabel);

        // Adjust positions and sizes based on new frame size
        logoLabel.setIcon(new ImageIcon(resizeImage(logoImage, 100, 100)));
        logoLabel.setBounds(100, 20, 100, 100);

        ImageIcon returnIcon = new ImageIcon("images/fleche_retour.png");
        Image returnImage = returnIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        returnIcon = new ImageIcon(returnImage);
        JButton retourButton = new JButton(returnIcon);

        retourButton.setBounds(20, 20, 50, 50);
        add(retourButton);
        retourButton.addActionListener(new SessionRetourListener());

        // Title
        JLabel titleLabel = new JLabel("Choisir une action", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setBounds(300, 50, 400, 30);
        add(titleLabel);

        // Left Action Button
        JButton manageButton = new JButton("<html>Gerer les epreuves<br>(Login requis)</html>");
        manageButton.setBounds(100, 200, 300, 400);
        manageButton.setBackground(new Color(  247, 216, 22 )); // Steel Blue
        manageButton.setForeground(Color.WHITE);
        add(manageButton);
        manageButton.addActionListener(new SessionLoginListener());

        // Right Action Button
        JButton viewButton = new JButton("Afficher les epreuves");
        viewButton.setBounds(600, 200, 300, 400);
        viewButton.setBackground(new Color(  247, 216, 22 )); // Forest Green
        viewButton.setForeground(Color.WHITE);
        add(viewButton);
        viewButton.addActionListener(new SessionAfficherListener());

        // Divider
        JSeparator separator = new JSeparator(SwingConstants.VERTICAL);
        separator.setBounds(500, 150, 1, 300);
        add(separator);

    }

    private BufferedImage resizeImage(BufferedImage originalImage, int targetWidth, int targetHeight) {
        Image resultingImage = originalImage.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
        BufferedImage outputImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = outputImage.createGraphics();
        g2d.drawImage(resultingImage, 0, 0, null);
        g2d.dispose();
        return outputImage;
    }

}

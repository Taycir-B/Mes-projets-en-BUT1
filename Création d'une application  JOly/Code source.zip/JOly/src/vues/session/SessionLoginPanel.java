package vues.session;

import controleurs.session.SessionGererListener;
import controleurs.session.SessionGererRetourListener;

import javax.swing.*;
import java.awt.*;

public class SessionLoginPanel extends JPanel {

    private JButton loginButton;

    public SessionLoginPanel() {
        setSize(1000, 700);
        setBackground(new Color(255, 215, 0)); // Golden background color

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Add some padding


        ImageIcon returnIcon = new ImageIcon("images/fleche_retour.png");
        Image returnImage = returnIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        returnIcon = new ImageIcon(returnImage);
        JButton backButton = new JButton(returnIcon);
        backButton.setPreferredSize(new Dimension(50, 50));

        backButton.addActionListener(new SessionGererRetourListener());
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        add(backButton, gbc);



        // Title label
        JLabel titleLabel = new JLabel("Olympic Login");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(titleLabel, gbc);

        // Create login form components
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setOpaque(false); // Make the panel transparent
        GridBagConstraints loginGbc = new GridBagConstraints();
        loginGbc.insets = new Insets(10, 10, 10, 10); // Padding for login components

        JLabel userLabel = new JLabel("User Login:");
        userLabel.setFont(new Font("Arial", Font.BOLD, 16));
        loginGbc.gridx = 0;
        loginGbc.gridy = 0;
        loginGbc.anchor = GridBagConstraints.WEST;
        loginPanel.add(userLabel, loginGbc);

        JTextField userText = new JTextField(20);
        loginGbc.gridx = 1;
        loginGbc.gridy = 0;
        loginPanel.add(userText, loginGbc);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 16));
        loginGbc.gridx = 0;
        loginGbc.gridy = 1;
        loginGbc.anchor = GridBagConstraints.WEST;
        loginPanel.add(passwordLabel, loginGbc);

        JPasswordField passwordText = new JPasswordField(20);
        loginGbc.gridx = 1;
        loginGbc.gridy = 1;
        loginPanel.add(passwordText, loginGbc);

        loginButton = new JButton("Login");
        loginGbc.gridx = 1;
        loginGbc.gridy = 2;
        loginGbc.anchor = GridBagConstraints.CENTER;
        loginPanel.add(loginButton, loginGbc);
        loginButton.addActionListener(new SessionGererListener(userText, passwordText));

        // Add login panel to the main panel
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(loginPanel, gbc);
    }
}

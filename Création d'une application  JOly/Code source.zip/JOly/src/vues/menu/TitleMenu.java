package vues.menu;

import javax.swing.*;
import java.awt.*;

/**
 * Classe représentant le titre du menu dans l'application.
 */
public class TitleMenu extends JLabel {

    /**
     * Constructeur du titre du menu.
     * @param text Le texte à afficher.
     */
    TitleMenu(String text) {
        super(text);
        setAlignmentX(Component.CENTER_ALIGNMENT);
        setFont(new Font("Consolas", Font.BOLD, 20));
    }

}

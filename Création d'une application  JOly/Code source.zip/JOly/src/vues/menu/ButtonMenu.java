package vues.menu;

import controleurs.menu.MenuButtonListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Classe représentant un bouton de menu personnalisé dans l'application.
 */
public class ButtonMenu extends JButton {

    private Color bgColor;
    private JPanel nextPanel;

    /**
     * Constructeur du bouton de menu.
     * @param text Le texte à afficher sur le bouton.
     * @param bgColor La couleur de fond du bouton.
     * @param nextPanel Le panneau vers lequel naviguer lorsque le bouton est cliqué.
     */
    ButtonMenu(String text, Color bgColor, JPanel nextPanel) {
        super(text);
        this.bgColor = bgColor;
        this.nextPanel = nextPanel;

        setBackground(bgColor);
        setForeground(Color.BLACK);
        setFont(new Font("Consolas", Font.BOLD, 16));
        setAlignmentX(Component.CENTER_ALIGNMENT);
        setPreferredSize(new Dimension(200, 40));
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.BLACK, 2),
                new EmptyBorder(10, 20, 10, 20)
        ));

        MenuButtonListener actionListener = new MenuButtonListener();
        addActionListener(actionListener);
    }

    /**
     * Méthode pour obtenir le panneau suivant.
     * @return Le panneau suivant.
     */
    public JPanel getNextPanel() {
        return nextPanel;
    }
}

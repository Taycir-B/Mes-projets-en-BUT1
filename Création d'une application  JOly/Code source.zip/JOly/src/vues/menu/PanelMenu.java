package vues.menu;


import javax.swing.*;
import java.awt.*;

/**
 * Classe représentant le panneau principal du menu.
 */
public class PanelMenu extends JPanel {
    private PanelLeftMenu leftPanel;
    private PanelRightMenu rightPanel;
    private PanelCenterMenu centerPanel;

    /**
     * Constructeur du panneau principal du menu.
     * Initialise et ajoute les panneaux gauche, centre et droit.
     */
    public PanelMenu() {
        setLayout(new BorderLayout());

        leftPanel = new PanelLeftMenu();
        leftPanel.setPreferredSize(new Dimension(300, 700));

        rightPanel = new PanelRightMenu();
        rightPanel.setPreferredSize(new Dimension(300, 700));

        centerPanel = new PanelCenterMenu();



        add(leftPanel, BorderLayout.WEST);
        add(centerPanel, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);
    }



}

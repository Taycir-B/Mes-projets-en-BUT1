package vues.menu;

import javax.swing.*;
import java.awt.*;

/**
 * Classe représentant le panneau gauche du menu.
 */
class PanelLeftMenu extends JPanel {

    /**
     * Constructeur du panneau gauche du menu.
     * Initialise l'arrière-plan, la bordure et l'image de la mascotte.
     */
    protected PanelLeftMenu() {
        setBackground(new Color(0, 0, 139));
        setBorder(BorderFactory.createMatteBorder(0, 10, 0, 0, new Color(0, 0, 139)));

        ImageIcon mascotLeftIcon = new ImageIcon("images/menu_left.png");
        Image leftImage = mascotLeftIcon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
        mascotLeftIcon = new ImageIcon(leftImage);
        JLabel mascotLeftLabel = new JLabel(mascotLeftIcon);
        add(mascotLeftLabel);
    }

}

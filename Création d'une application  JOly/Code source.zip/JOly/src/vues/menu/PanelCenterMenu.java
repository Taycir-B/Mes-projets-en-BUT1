package vues.menu;

import javax.swing.*;
import java.awt.*;
import main.Main;

/**
 * Classe représentant le panneau central du menu.
 */
class PanelCenterMenu extends JPanel {

    private ButtonMenu equipeButton;
    private ButtonMenu sessionButton;
    private ButtonMenu resultButton;
    private ButtonMenu statButton;

    /**
     * Constructeur du panneau central du menu.
     */
    PanelCenterMenu() {
        setBackground(Color.WHITE);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        System.out.println(Main.equipePanel.getClass().getName());
        equipeButton = new ButtonMenu("Equipes", Color.RED, Main.equipePanel);
        sessionButton = new ButtonMenu("Sessions et epreuves", Color.YELLOW, Main.choiceSession);
        resultButton = new ButtonMenu("Resultats", Color.CYAN, new JPanel());
        statButton = new ButtonMenu("Statistiques", Color.GREEN, new JPanel());


        add(Box.createRigidArea(new Dimension(0, 20)));
        add(new LogoMenu());
        add(Box.createRigidArea(new Dimension(0, 20)));
        add(new TitleMenu("Bienvenue sur JOly !"));
        add(Box.createRigidArea(new Dimension(0, 20)));
        add(equipeButton);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(sessionButton);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(resultButton);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(statButton);
    }

}

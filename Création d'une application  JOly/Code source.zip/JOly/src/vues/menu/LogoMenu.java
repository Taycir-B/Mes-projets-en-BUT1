package vues.menu;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Classe représentant le logo du menu dans l'application.
 */
public class LogoMenu extends JLabel {
    /**
     * Constructeur du logo du menu.
     * Initialise l'image du logo et ses propriétés.
     */
    LogoMenu() {
        ImageIcon olympicLogoIcon = new ImageIcon("images/menu_logo.png");
        Image logo = olympicLogoIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        olympicLogoIcon = new ImageIcon(logo);
        setIcon(olympicLogoIcon);
        setAlignmentX(Component.CENTER_ALIGNMENT);
    }

}

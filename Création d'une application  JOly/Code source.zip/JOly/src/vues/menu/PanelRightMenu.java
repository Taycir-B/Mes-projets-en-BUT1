package vues.menu;

import javax.swing.*;
import java.awt.*;

/**
 * Classe représentant le panneau droit du menu.
 */
class PanelRightMenu extends JPanel {

    /**
     * Constructeur du panneau droit du menu.
     * Initialise l'arrière-plan, la bordure et l'image de la mascotte.
     */
    protected PanelRightMenu() {
        setLayout(new BorderLayout());
        setBackground(new Color(255, 0, 0));
        setBorder(BorderFactory.createMatteBorder(0, 0, 0, 10, new Color(255, 0, 0)));

        JPanel bottomRightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        bottomRightPanel.setOpaque(false);

        ImageIcon mascotRightIcon = new ImageIcon("images/menu_right.png");
        Image rightImage = mascotRightIcon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
        mascotRightIcon = new ImageIcon(rightImage);
        JLabel mascotRightLabel = new JLabel(mascotRightIcon);
        bottomRightPanel.add(mascotRightLabel);

        add(bottomRightPanel, BorderLayout.SOUTH);
    }

}

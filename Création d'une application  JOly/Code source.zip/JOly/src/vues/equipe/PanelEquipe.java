package vues.equipe;

import controleurs.equipe.EquipeBackButtonListener;
import controleurs.equipe.EquipeCreateListener;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * Classe representant le panneau de gestion des equipes.
 */
public class PanelEquipe extends JPanel {
    private JPanel centerPanel;
    private GridBagConstraints gbc;
    private ArrayList<ButtonEquipe> teamButtons;
    private JScrollPane scrollPane;

    private JButton createTeamButton;

    private JButton backButton;

    public JTextField teamNameField;
    public JTextField countryNameField;

    /**
     * Constructeur du panneau de gestion des equipes.
     * Initialise les composants de l'interface graphique.
     */
    public PanelEquipe() {
        // Initialiser la liste des boutons d'equipe
        teamButtons = new ArrayList<>();

        // Configurer le panneau principal
        setLayout(new GridBagLayout());
        setBackground(new Color(232, 54, 54)); // Tomato color
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components

        // Creer le panneau superieur pour le titre
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setOpaque(false); // Make the panel transparent

        // Redimensionner l'icône de retour
        ImageIcon backIcon = new ImageIcon("images/equipe_back_icon.png"); // Add the path to your back icon image
        Image backImage = backIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH); // Resize image to 30x30
        backIcon = new ImageIcon(backImage);

        JLabel backLabel = new JLabel(backIcon); // Add the resized icon to the label
        JLabel titleLabel = new JLabel("Equipes");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));

        // Ajouter le bouton de retour au panneau superieur
        ImageIcon returnIcon = new ImageIcon("images/fleche_retour.png"); // Path to your back arrow image
        Image returnImage = returnIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH); // Resize image to 30x30
        returnIcon = new ImageIcon(returnImage);

        backButton = new JButton(returnIcon);
        backButton.setOpaque(false);
        backButton.setContentAreaFilled(false);
        backButton.setBorderPainted(false);
        backButton.addActionListener(new EquipeBackButtonListener());

        topPanel.add(backButton);
        topPanel.add(backLabel);
        topPanel.add(titleLabel);

        // Ajouter le panneau superieur au panneau principal
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.WEST;
        add(topPanel, gbc);

        // Creer le panneau gauche pour l'image de la mascotte gauche
        JPanel leftPanel = new JPanel();
        leftPanel.setOpaque(false); // Make the panel transparent
        ImageIcon leftMascotIcon = new ImageIcon("images/equipe_left_mascot.png"); // Add the path to your image
        Image leftImage = leftMascotIcon.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH); // Resize image
        leftMascotIcon = new ImageIcon(leftImage);
        JLabel leftMascotLabel = new JLabel(leftMascotIcon);
        leftPanel.add(leftMascotLabel);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        add(leftPanel, gbc);

        // Creer le panneau droit pour l'image de la mascotte droite
        JPanel rightPanel = new JPanel();
        rightPanel.setOpaque(false); // Make the panel transparent
        ImageIcon rightMascotIcon = new ImageIcon("images/equipe_right_mascot.png"); // Add the path to your image
        Image rightImage = rightMascotIcon.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH); // Resize image
        rightMascotIcon = new ImageIcon(rightImage);
        JLabel rightMascotLabel = new JLabel(rightMascotIcon);
        rightPanel.add(rightMascotLabel);
        gbc.gridx = 2;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        add(rightPanel, gbc);

        // Creer le panneau central pour la liste des equipes
        centerPanel = new JPanel();
        centerPanel.setOpaque(false); // Make the panel transparent
        centerPanel.setLayout(new GridBagLayout());

        // Titre pour la liste des equipes
        JLabel teamsTitleLabel = new JLabel("Nos Equipes");
        teamsTitleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        teamsTitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Ajouter le titre au panneau central
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        centerPanel.add(teamsTitleLabel, gbc);

        // Ajouter les champs de texte pour le nom de l'equipe et le nom du pays
        teamNameField = new JTextField(20);
        countryNameField = new JTextField(20);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 0, 10, 0);
        centerPanel.add(new JLabel("Nom de l'equipe:"), gbc);

        gbc.gridy = 2;
        centerPanel.add(teamNameField, gbc);

        gbc.gridy = 3;
        centerPanel.add(new JLabel("Nom du pays:"), gbc);

        gbc.gridy = 4;
        centerPanel.add(countryNameField, gbc);

        // Bouton pour creer une nouvelle equipe
        createTeamButton = new JButton("Ajoutez une Equipe !");
        createTeamButton.setFont(new Font("Arial", Font.BOLD, 16));
        createTeamButton.setBackground(new Color(229, 126, 126)); // Light pink
        createTeamButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Ajouter le bouton de creation au panneau central
        gbc.gridy = 5;
        gbc.insets = new Insets(20, 0, 0, 0);
        centerPanel.add(createTeamButton, gbc);


        // Ajouter l'ecouteur au bouton de creation d'equipe
        createTeamButton.addActionListener(new EquipeCreateListener());


        // Encadrer le panneau central dans un JScrollPane
        scrollPane = new JScrollPane(centerPanel);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setPreferredSize(new Dimension(400, 500));

        // Ajouter le panneau de defilement au panneau principal
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridheight = 2;
        gbc.fill = GridBagConstraints.BOTH;
        add(scrollPane, gbc);
    }

    /**
     * Methode pour ajouter un bouton d'equipe.
     * @param button Le bouton d'equipe à ajouter.
     */
    public void addTeamButton(ButtonEquipe button) {
        teamButtons.add(button);
        refreshTeamButtons();
    }

    /**
     * Methode pour supprimer un bouton d'equipe.
     * @param button Le bouton d'equipe à supprimer.
     */
    public void removeTeamButton(ButtonEquipe button) {
        main.Main.equipes.remove(button.equipe);
        teamButtons.remove(button);
        refreshTeamButtons();
    }


    /**
     * Methode pour rafraichir les boutons d'equipe affiches.
     */
    private void refreshTeamButtons() {
        centerPanel.removeAll();

        // Title for the teams list
        JLabel teamsTitleLabel = new JLabel("Nos Equipes");
        teamsTitleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        teamsTitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        centerPanel.add(teamsTitleLabel, gbc);

        // Add text fields for team name and country name
        gbc.gridy = 1;
        centerPanel.add(new JLabel("Nom de l'equipe:"), gbc);

        gbc.gridy = 2;
        centerPanel.add(teamNameField, gbc);

        gbc.gridy = 3;
        centerPanel.add(new JLabel("Nom du pays:"), gbc);

        gbc.gridy = 4;
        centerPanel.add(countryNameField, gbc);

        gbc.gridy = 5;
        gbc.insets = new Insets(20, 0, 0, 0);
        centerPanel.add(createTeamButton, gbc);

        // Add team buttons
        gbc.insets = new Insets(10, 0, 10, 0);
        gbc.gridx = 0;
        gbc.gridy = 6;
        for (ButtonEquipe button : teamButtons) {
            centerPanel.add(button, gbc);
            gbc.gridy++;
        }

        revalidate();
        repaint();
    }


}
package vues.equipe;

import controleurs.equipe.EquipeAthleteDeleteListener;
import modeles.Athlete;

import javax.swing.*;
import java.awt.*;


/**
 * Classe representant un bouton personnalise pour l'equipe d'athletes dans l'application.
 */
public class ButtonEquipeAthlete extends JButton {

    JButton deleteButton;
    Athlete athlete;

    /**
     * Constructeur du bouton pour l'equipe d'athletes.
     * @param nom Nom de l'athlete.
     * @param prenom Prenom de l'athlete.
     * @param age Age de l'athlete.
     * @param mail Mail de l'athlete.
     * @param poids Poids de l'athlete.
     * @param taille Taille de l'athlete.
     */
    public ButtonEquipeAthlete(String nom, String prenom, String age, String mail, String poids, String taille) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setOpaque(false);

        JLabel nomAthleteLabel = new JLabel("Nom : " + nom);
        nomAthleteLabel.setFont(new Font("Arial", Font.BOLD, 16));

        JLabel prenomAthleteLabel = new JLabel("Prenom : " + prenom);
        prenomAthleteLabel.setFont(new Font("Arial", Font.BOLD, 16));

        JLabel ageAthleteLabel = new JLabel("Age : " + age);
        ageAthleteLabel.setFont(new Font("Arial", Font.BOLD, 16));

        JLabel mailAthleteLabel = new JLabel("Mail : " + mail);
        mailAthleteLabel.setFont(new Font("Arial", Font.BOLD, 16));

        JLabel poidsAthleteLabel = new JLabel("Poids (kg) : " + poids);
        poidsAthleteLabel.setFont(new Font("Arial", Font.BOLD, 16));

        JLabel tailleAthleteLabel = new JLabel("Taille (cm) : " + taille);
        tailleAthleteLabel.setFont(new Font("Arial", Font.BOLD, 16));


        ImageIcon deleteIcon = new ImageIcon("images/equipe_delete_icon.png"); // Add the path to your delete icon image
        Image deleteImage = deleteIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH); // Resize image to 20x20
        deleteIcon = new ImageIcon(deleteImage);
        deleteButton = new JButton(deleteIcon);
        deleteButton.setPreferredSize(new Dimension(30, 30));
        deleteButton.addActionListener(new EquipeAthleteDeleteListener());

        panel.add(Box.createRigidArea(new Dimension(20, 0)));
        panel.add(nomAthleteLabel);
        panel.add(Box.createRigidArea(new Dimension(20, 0)));
        panel.add(prenomAthleteLabel);
        panel.add(Box.createRigidArea(new Dimension(20, 0)));
        panel.add(ageAthleteLabel);
        panel.add(Box.createRigidArea(new Dimension(25, 0)));
        panel.add(mailAthleteLabel);
        panel.add(Box.createRigidArea(new Dimension(25, 0)));
        panel.add(tailleAthleteLabel);
        panel.add(Box.createRigidArea(new Dimension(25, 0)));
        panel.add(poidsAthleteLabel);
        panel.add(Box.createRigidArea(new Dimension(30, 0)));
        panel.add(deleteButton);

        setLayout(new BorderLayout());
        add(panel, BorderLayout.CENTER);
        setBackground(new Color(255, 182, 193)); // Light pink
        setBorderPainted(false);
        setPreferredSize(new Dimension(350, 150));

        athlete = new Athlete(nom, prenom, Integer.parseInt(age), mail, poids, taille);



    }

}

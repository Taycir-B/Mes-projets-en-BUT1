package vues.equipe;

import javax.swing.*;
import java.awt.*;

/**
 * Classe representant la mascotte de la page equipe dans l'application.
 */
public class MascotteEquipe extends JLabel {
    /**
     * Constructeur de la mascotte de la page equipe.
     * Initialise l'image de la mascotte et ses proprietes.
     * @param imagepath Le chemin de l'image de la mascotte.
     * @param compAlignement L'alignement horizontal du composant.
     */
    MascotteEquipe(String imagepath, float compAlignement) {
        ImageIcon olympicLogoIcon = new ImageIcon(imagepath);
        Image logo = olympicLogoIcon.getImage().getScaledInstance(200, 300, Image.SCALE_SMOOTH);
        olympicLogoIcon = new ImageIcon(logo);
        setIcon(olympicLogoIcon);
        setAlignmentX(compAlignement);
    }
}

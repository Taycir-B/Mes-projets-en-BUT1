package vues.equipe;

import controleurs.equipe.EquipeAthleteBackButtonListener;
import controleurs.equipe.EquipeAthleteCreateListener;
import modeles.Equipe;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * Classe representant le panneau de gestion des athletes d'une equipe.
 */
public class PanelEquipeAthletes extends JPanel {

    private JPanel centerPanel;
    private GridBagConstraints gbc;
    private ArrayList<ButtonEquipeAthlete> athleteButtons;
    private JScrollPane scrollPane;

    private JButton createAthleteButton;

    private JButton backButton;

    private Equipe equipe;

    public JTextField athleteNameField;
    public JTextField athleteFirstNameField;
    public JTextField ageField;
    public JTextField emailField;
    public JTextField weightField;
    public JTextField heightField;

    /**
     * Constructeur du panneau de gestion des athletes d'une equipe.
     * @param equipe L'equipe dont les athletes sont geres.
     */
    public PanelEquipeAthletes(Equipe equipe) {
        // Initialize the athlete buttons list
        this.equipe = equipe;
        athleteButtons = new ArrayList<>();

        // Set up the main panel
        setLayout(new GridBagLayout());
        setBackground(new Color(232, 54, 54)); // Tomato color
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components

        // Create the top panel for the title
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setOpaque(false); // Make the panel transparent

        // Resize the back icon
        ImageIcon backIcon = new ImageIcon("images/equipe_back_icon.png"); // Add the path to your back icon image
        Image backImage = backIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH); // Resize image to 30x30
        backIcon = new ImageIcon(backImage);

        JLabel backLabel = new JLabel(backIcon); // Add the resized icon to the label
        JLabel titleLabel = new JLabel("Athletes");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));

        // Add back button to the top panel
        ImageIcon returnIcon = new ImageIcon("images/fleche_retour.png"); // Path to your back arrow image
        Image returnImage = returnIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH); // Resize image to 30x30
        returnIcon = new ImageIcon(returnImage);

        backButton = new JButton(returnIcon);
        backButton.setOpaque(false);
        backButton.setContentAreaFilled(false);
        backButton.setBorderPainted(false);
        backButton.addActionListener(new EquipeAthleteBackButtonListener());

        topPanel.add(backButton);
        topPanel.add(backLabel);
        topPanel.add(titleLabel);

        // Add the top panel to the main panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.WEST;
        add(topPanel, gbc);

        // Create the left panel for the left mascot image
        JPanel leftPanel = new JPanel();
        leftPanel.setOpaque(false); // Make the panel transparent
        ImageIcon leftMascotIcon = new ImageIcon("images/equipe_left_mascot.png"); // Add the path to your image
        Image leftImage = leftMascotIcon.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH); // Resize image
        leftMascotIcon = new ImageIcon(leftImage);
        JLabel leftMascotLabel = new JLabel(leftMascotIcon);
        leftPanel.add(leftMascotLabel);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        add(leftPanel, gbc);

        // Create the right panel for the right mascot image
        JPanel rightPanel = new JPanel();
        rightPanel.setOpaque(false); // Make the panel transparent
        ImageIcon rightMascotIcon = new ImageIcon("images/equipe_right_mascot.png"); // Add the path to your image
        Image rightImage = rightMascotIcon.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH); // Resize image
        rightMascotIcon = new ImageIcon(rightImage);
        JLabel rightMascotLabel = new JLabel(rightMascotIcon);

        rightPanel.add(rightMascotLabel);
        gbc.gridx = 2;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        add(rightPanel, gbc);

        // Create the center panel for the athletes list
        centerPanel = new JPanel();
        centerPanel.setOpaque(false); // Make the panel transparent
        centerPanel.setLayout(new GridBagLayout());

        // Title for the athletes list
        JLabel athletesTitleLabel = new JLabel("Nos Athletes");
        athletesTitleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        athletesTitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Add title to the center panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        centerPanel.add(athletesTitleLabel, gbc);

        // Add text fields for athlete name and country name
        athleteNameField = new JTextField(20);
        athleteFirstNameField = new JTextField(20);
        ageField = new JTextField(20);
        emailField = new JTextField(20);
        weightField = new JTextField(20);
        heightField = new JTextField(20);

        // Button to create a new athlete
        createAthleteButton = new JButton("Ajoutez un Athlete !");
        createAthleteButton.setFont(new Font("Arial", Font.BOLD, 16));
        createAthleteButton.setBackground(new Color(229, 126, 126)); // Light pink
        createAthleteButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        createAthleteButton.addActionListener(new EquipeAthleteCreateListener());


        refreshAthleteButtons();


        // Wrap the center panel in a JScrollPane
        scrollPane = new JScrollPane(centerPanel);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setPreferredSize(new Dimension(400, 500));

        // Add scroll pane to the main panel
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridheight = 2;
        gbc.fill = GridBagConstraints.BOTH;
        add(scrollPane, gbc);
    }

    /**
     * Methode pour ajouter un bouton d'athlete.
     * @param button Le bouton d'athlete à ajouter.
     */
    public void addAthleteButton(ButtonEquipeAthlete button) {
        equipe.ajoutMembre(button.athlete);
        athleteButtons.add(button);
        refreshAthleteButtons();
    }

    /**
     * Methode pour supprimer un bouton d'athlete.
     * @param button Le bouton d'athlete à supprimer.
     */
    public void removeAthleteButton(ButtonEquipeAthlete button) {
        equipe.suppressionMembre(button.athlete);
        athleteButtons.remove(button);
        refreshAthleteButtons();
    }

    /**
     * Methode pour rafraichir les boutons d'athlete affiches.
     */
    protected void refreshAthleteButtons() {
        centerPanel.removeAll();

        // Title for the athletes list
        JLabel athletesTitleLabel = new JLabel("Nos Athletes");
        athletesTitleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        athletesTitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0);

        // Add title to the center panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.gridheight = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        centerPanel.add(athletesTitleLabel, gbc);

        // Add labels and text fields for athlete details
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridy = 1;
        centerPanel.add(new JLabel("Nom de l'athlete:"), gbc);
        gbc.gridx = 1;
        centerPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        centerPanel.add(athleteNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        centerPanel.add(new JLabel("Prenom de l'athlete:"), gbc);
        gbc.gridx = 1;
        centerPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        centerPanel.add(athleteFirstNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        centerPanel.add(new JLabel("Age de l'athlete:"), gbc);
        gbc.gridx = 1;
        centerPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        centerPanel.add(ageField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        centerPanel.add(new JLabel("Email de l'athlete:"), gbc);
        gbc.gridx = 1;
        centerPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        centerPanel.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        centerPanel.add(new JLabel("Poids athlete (kg):"), gbc);
        gbc.gridx = 1;
        centerPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        centerPanel.add(weightField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        centerPanel.add(new JLabel("Taille athlete (cm):"), gbc);
        gbc.gridx = 1;
        centerPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        centerPanel.add(heightField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 0, 0, 0);
        centerPanel.add(createAthleteButton, gbc);

        // Add athlete buttons
        gbc.gridwidth = 1;
        gbc.insets = new Insets(10, 0, 10, 0);

        for (ButtonEquipeAthlete button : athleteButtons) {
            gbc.gridx = 0;
            gbc.gridy++;
            gbc.gridwidth = 2; // Make sure the button spans across both columns
            centerPanel.add(button, gbc);
        }

        revalidate();
        repaint();
    }
}

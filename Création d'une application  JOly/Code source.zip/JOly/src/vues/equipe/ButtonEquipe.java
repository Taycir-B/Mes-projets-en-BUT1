package vues.equipe;

import controleurs.equipe.EquipeDeleteListener;
import controleurs.equipe.EquipeEditListener;
import modeles.Equipe;

import javax.swing.*;
import java.awt.*;

/**
 * Classe representant un bouton personnalise pour l'equipe dans l'application.
 */
public class ButtonEquipe extends JButton {

    JButton deleteButton;

    JButton editButton;

    Equipe equipe;

    /**
     * Constructeur du bouton de l'equipe.
     * @param teamName Le nom de l'equipe à afficher sur le bouton.
     * @param pays Le nom du pays rattache a l'equipe.
     */
    public ButtonEquipe(String teamName, String pays) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setOpaque(false);

        JLabel teamLabel = new JLabel(teamName);
        teamLabel.setFont(new Font("Arial", Font.BOLD, 16));

        JLabel paysLabel = new JLabel(pays);
        paysLabel.setFont(new Font("Arial", Font.BOLD, 16));

        ImageIcon deleteIcon = new ImageIcon("images/equipe_delete_icon.png"); // Add the path to your delete icon image
        Image deleteImage = deleteIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH); // Resize image to 20x20
        deleteIcon = new ImageIcon(deleteImage);
        deleteButton = new JButton(deleteIcon);
        deleteButton.setPreferredSize(new Dimension(30, 30));
        deleteButton.addActionListener(new EquipeDeleteListener());

        ImageIcon editIcon = new ImageIcon("images/equipe_edit_icon.png"); // Add the path to your edit icon image
        Image editImage = editIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH); // Resize image to 20x20
        editIcon = new ImageIcon(editImage);
        editButton = new JButton(editIcon);
        editButton.setPreferredSize(new Dimension(30, 30));
        editButton.addActionListener(new EquipeEditListener());

        panel.add(Box.createRigidArea(new Dimension(10, 0)));
        panel.add(teamLabel);
        panel.add(Box.createRigidArea(new Dimension(25, 0)));
        panel.add(paysLabel);
        panel.add(Box.createRigidArea(new Dimension(30, 0)));
        panel.add(editButton);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));
        panel.add(deleteButton);

        setLayout(new BorderLayout());
        add(panel, BorderLayout.CENTER);
        setBackground(new Color(255, 182, 193)); // Light pink
        setBorderPainted(false);
        setPreferredSize(new Dimension(350, 50));

        equipe = new Equipe(teamName, pays);

    }

    /**
     * Methode pour obtenir le panneau suivant.
     * @return Le panneau suivant.
     */
    public Equipe getEquipe() {
        return equipe;
    }
}


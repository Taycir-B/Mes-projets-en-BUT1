package controleurs.menu;

import vues.menu.ButtonMenu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Classe representant l'ecouteur d'evenements pour les boutons de menu.
 */
public class MenuButtonListener implements ActionListener {
    /**
     * Methode appelee lorsqu'une action est effectuee.
     * @param e L'evenement d'action declenche.
     */
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() instanceof ButtonMenu) {
            ButtonMenu button = (ButtonMenu) e.getSource();
            Container fenetre = button.getParent();
            while (!(fenetre instanceof JFrame)) {
                fenetre = fenetre.getParent();
            }
            //System.out.println(button.getNextPanel().getClass().getName());
            JFrame frame = (JFrame) fenetre;
            frame.getContentPane().removeAll();
            frame.getContentPane().add(button.getNextPanel());
            frame.getContentPane().revalidate();
            frame.getContentPane().repaint();

        }

    }

}

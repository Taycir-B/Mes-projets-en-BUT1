package controleurs.session;

import main.Main;
import modeles.Session;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SessionAjouterListener implements ActionListener {
    JTextField sportField;
    JTextField startDateField;
    JTextField durationField;
    JTextField descriptionField;
    public SessionAjouterListener(JTextField sportField, JTextField startDateField, JTextField durationField, JTextField descriptionField) {
        this.sportField = sportField;
        this.startDateField = startDateField;
        this.durationField = durationField;
        this.descriptionField = descriptionField;
    }

    public void actionPerformed(ActionEvent e) {
        String sport = sportField.getText();
        String startDate = startDateField.getText();
        String duration = durationField.getText();
        String description = descriptionField.getText();
        Main.planningSession.addSession(new Session(sport, startDate, duration, description));

        sportField.setText("");
        startDateField.setText("");
        durationField.setText("");
        descriptionField.setText("");

    }
}

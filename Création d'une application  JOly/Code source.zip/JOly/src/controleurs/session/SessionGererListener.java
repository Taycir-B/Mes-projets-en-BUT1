package controleurs.session;

import main.Main;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SessionGererListener implements ActionListener {

        JTextField usernameField;
        JPasswordField passwordField;

        public SessionGererListener(JTextField usernameField, JPasswordField passwordField) {
            this.usernameField = usernameField;
            this.passwordField = passwordField;
        }
        public void actionPerformed(ActionEvent e) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            if (username.equals("admin") && password.equals("admin")) {
                Main.fenetre.getContentPane().removeAll();
                Main.fenetre.add(Main.sessionGerer);
                Main.fenetre.revalidate();
                Main.fenetre.repaint();
            } else {
                JOptionPane.showMessageDialog(null, "Mauvais identifiants");
            }

            usernameField.setText("");
            passwordField.setText("");

        }
}

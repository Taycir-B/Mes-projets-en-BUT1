package controleurs.session;

import main.Main;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SessionGererRetourListener implements ActionListener {

            public void actionPerformed(ActionEvent e) {
                Main.fenetre.getContentPane().removeAll();
                Main.fenetre.add(Main.choiceSession);
                Main.fenetre.revalidate();
                Main.fenetre.repaint();
            }

}

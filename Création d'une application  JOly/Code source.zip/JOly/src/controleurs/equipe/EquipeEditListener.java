package controleurs.equipe;

import main.Main;
import vues.equipe.ButtonEquipe;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Component;

/**
 * Classe representant l'ecouteur pour l'edition d'une equipe.
 */
public class EquipeEditListener implements ActionListener {

    /**
     * Methode appelee lors du clic sur le bouton d'edition.
     * @param e L'evenement d'action declenche.
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            Component source = (Component) e.getSource();
            while (!(source instanceof ButtonEquipe)) {
                source = source.getParent();
            }
            ButtonEquipe buttonEquipe = (ButtonEquipe) source;

            Main.fenetre.getContentPane().removeAll();
            Main.fenetre.add(buttonEquipe.getEquipe().panelAthletes);
            Main.fenetre.revalidate();
            Main.fenetre.repaint();
        }
    }

}

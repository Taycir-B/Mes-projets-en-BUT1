package controleurs.equipe;

import vues.equipe.ButtonEquipeAthlete;
import vues.equipe.PanelEquipeAthletes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Classe representant l'ecouteur pour la creation d'une equipe d'athletes.
 */
public class EquipeAthleteCreateListener implements ActionListener {

    /**
     * Methode appelee lors du clic sur le bouton de creation.
     * @param e L'evenement d'action declenche.
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            Component parentComp = (Component) e.getSource();
            while (!(parentComp instanceof PanelEquipeAthletes)) {
                parentComp = parentComp.getParent();
            }
            PanelEquipeAthletes panelEquipeAthletes = (PanelEquipeAthletes) parentComp;
            String athleteName = panelEquipeAthletes.athleteNameField.getText();
            String athleteFirsName = panelEquipeAthletes.athleteFirstNameField.getText();
            String athleteAge = panelEquipeAthletes.ageField.getText();
            String athleteMail = panelEquipeAthletes.emailField.getText();
            String athleteWeight = panelEquipeAthletes.weightField.getText();
            String athleteHeight = panelEquipeAthletes.heightField.getText();
            if (!athleteName.isEmpty() && !athleteFirsName.isEmpty() && !athleteAge.isEmpty() && !athleteMail.isEmpty() && !athleteWeight.isEmpty() && !athleteHeight.isEmpty()){

                panelEquipeAthletes.addAthleteButton(new ButtonEquipeAthlete(athleteName, athleteFirsName, athleteAge, athleteMail, athleteWeight, athleteHeight));

                panelEquipeAthletes.athleteFirstNameField.setText("");
                panelEquipeAthletes.athleteNameField.setText("");
                panelEquipeAthletes.ageField.setText("");
                panelEquipeAthletes.emailField.setText("");
                panelEquipeAthletes.weightField.setText("");
                panelEquipeAthletes.heightField.setText("");

                panelEquipeAthletes.revalidate();
                panelEquipeAthletes.repaint();

            } else {
                JOptionPane.showMessageDialog(panelEquipeAthletes, "Veuillez entrer le nom, prenom, age et mail de l'athlete", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }

    }

}

package controleurs.equipe;

import vues.equipe.ButtonEquipe;
import vues.equipe.PanelEquipe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Classe representant l'ecouteur pour la creation d'une equipe.
 */
public class EquipeCreateListener implements ActionListener {

    /**
     * Methode appelee lors du clic sur le bouton de creation.
     * @param e L'evenement d'action declenche.
     */
    public void actionPerformed(java.awt.event.ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            Component parentComp = (Component) e.getSource();
            while (!(parentComp instanceof PanelEquipe)) {
                parentComp = parentComp.getParent();
            }
            PanelEquipe panelEquipe = (PanelEquipe) parentComp;
            String teamName = panelEquipe.teamNameField.getText();
            String countryName = panelEquipe.countryNameField.getText();
            if (!teamName.isEmpty() && !countryName.isEmpty()) {
                panelEquipe.addTeamButton(new ButtonEquipe(teamName, countryName));
                panelEquipe.teamNameField.setText("");
                panelEquipe.countryNameField.setText("");
                panelEquipe.revalidate();
                panelEquipe.repaint();
            } else {
                JOptionPane.showMessageDialog(panelEquipe, "Veuillez entrer le nom de l'equipe et du pays", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }

    }
}

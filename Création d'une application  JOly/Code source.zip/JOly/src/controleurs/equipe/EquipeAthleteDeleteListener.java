package controleurs.equipe;

import vues.equipe.ButtonEquipeAthlete;
import vues.equipe.PanelEquipeAthletes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Classe representant l'ecouteur pour la suppression d'une equipe d'athletes.
 */
public class EquipeAthleteDeleteListener implements ActionListener {

    /**
     * Methode appelee lors du clic sur le bouton de suppression.
     * @param e L'evenement d'action declenche.
     */
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() instanceof JButton) {

            Component source = (Component) e.getSource();

            while (!(source instanceof PanelEquipeAthletes)) {
                source = source.getParent();
            }

            System.out.println(source.getClass().getName());

            PanelEquipeAthletes panel = (PanelEquipeAthletes) source;
            ;
            source = (Component) e.getSource();

            while (!(source instanceof ButtonEquipeAthlete)) {
                source = source.getParent();
            }

            System.out.println(source.getClass().getName());

            ButtonEquipeAthlete button = (ButtonEquipeAthlete) source;

            panel.removeAthleteButton(button);


        }

    }

}

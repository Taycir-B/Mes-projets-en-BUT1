package controleurs.equipe;

import main.Main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Classe representant l'ecouteur du bouton de retour pour l'equipe.
 */
public class EquipeBackButtonListener implements ActionListener {

    /**
     * Methode appelee lors du clic sur le bouton de retour.
     * @param e L'evenement d'action declenche.
     */
    public void actionPerformed(ActionEvent e) {
        Main.fenetre.getContentPane().removeAll();
        Main.fenetre.getContentPane().add(Main.menu);
        Main.fenetre.getContentPane().revalidate();
        Main.fenetre.getContentPane().repaint();
    }
}

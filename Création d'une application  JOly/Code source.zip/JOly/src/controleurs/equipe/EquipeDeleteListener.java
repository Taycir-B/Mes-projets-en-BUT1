package controleurs.equipe;

import vues.equipe.ButtonEquipe;
import vues.equipe.PanelEquipe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Classe representant l'ecouteur pour la suppression d'une equipe.
 */
public class EquipeDeleteListener implements ActionListener {

    /**
     * Methode appelee lors du clic sur le bouton de suppression.
     * @param e L'evenement d'action declenche.
     */
    public void actionPerformed(java.awt.event.ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            Component parentComp = (Component) e.getSource();
            while (!(parentComp instanceof PanelEquipe)) {
                parentComp = parentComp.getParent();
            }

            PanelEquipe panelEquipe = (PanelEquipe) parentComp;


            parentComp = (Component) e.getSource();
            while  (!(parentComp instanceof ButtonEquipe)) {
                parentComp = parentComp.getParent();
            }

            ButtonEquipe buttonEquipe = (ButtonEquipe) parentComp;

            panelEquipe.removeTeamButton(buttonEquipe);
        }
    }
}

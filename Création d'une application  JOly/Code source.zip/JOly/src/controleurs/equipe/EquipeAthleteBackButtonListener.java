package controleurs.equipe;

import main.Main;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Classe representant l'ecouteur du bouton de retour pour l'equipe d'athletes.
 */
public class EquipeAthleteBackButtonListener implements ActionListener {


    /**
     * Methode appelee lors du clic sur le bouton de retour.
     * @param e L'evenement d'action declenche.
     */
    public void actionPerformed(ActionEvent e) {
        Main.fenetre.getContentPane().removeAll();
        Main.fenetre.getContentPane().add(Main.equipePanel);
        Main.fenetre.getContentPane().revalidate();
        Main.fenetre.getContentPane().repaint();
    }
}

package main;
import vues.equipe.PanelEquipe;
import vues.menu.PanelMenu;
import modeles.Equipe;
import modeles.Pays;
import vues.session.SessionChoicePanel;
import vues.session.SessionGererPanel;
import vues.session.SessionPlanningPanel;
import vues.session.SessionLoginPanel;


import javax.swing.*;
import java.util.ArrayList;

public class Main {
    public static PanelEquipe equipePanel;

    public static PanelMenu menu;

    public static SessionPlanningPanel planningSession;

    public static SessionLoginPanel loginSession;

    public static SessionChoicePanel choiceSession;

    public static SessionGererPanel sessionGerer;

    public static ArrayList<Pays> pays;
    public static ArrayList<Equipe> equipes;

    public static JFrame fenetre = new JFrame();

    static {
        pays = new ArrayList<Pays>();
        equipes = new ArrayList<Equipe>();
        equipePanel = new PanelEquipe();
        planningSession = new SessionPlanningPanel();
        loginSession = new SessionLoginPanel();
        choiceSession = new SessionChoicePanel();
        sessionGerer = new SessionGererPanel();
        menu = new PanelMenu();
    }

    public static void main(String[] args) {

        // fais une fenetre
        fenetre = new JFrame("Fenetre");
        fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fenetre.setSize(1000, 700);
        fenetre.setResizable(false);

        fenetre.add(menu);

        fenetre.setVisible(true);


    }
}